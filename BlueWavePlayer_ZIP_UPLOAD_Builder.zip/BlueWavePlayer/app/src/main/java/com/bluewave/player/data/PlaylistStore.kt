package com.bluewave.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class PlaylistStore(context: Context) {
    private val prefs = context.getSharedPreferences("bluewave_playlists", Context.MODE_PRIVATE)
    private val key = "items"

    @Synchronized fun all(): List<UserPlaylist> {
        val raw = prefs.getString(key, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        return buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val uris = obj.optJSONArray("uris") ?: JSONArray()
                add(UserPlaylist(obj.optString("id"), obj.optString("name"),
                    (0 until uris.length()).map { uris.optString(it) }))
            }
        }
    }

    @Synchronized fun create(name: String): UserPlaylist {
        val item = UserPlaylist(UUID.randomUUID().toString(), name.trim(), emptyList())
        save(all() + item)
        return item
    }

    @Synchronized fun add(playlistId: String, uri: String) {
        val updated = all().map { p ->
            if (p.id == playlistId && uri !in p.mediaUris) p.copy(mediaUris = p.mediaUris + uri) else p
        }
        save(updated)
    }

    @Synchronized fun delete(playlistId: String) = save(all().filterNot { it.id == playlistId })

    private fun save(items: List<UserPlaylist>) {
        val array = JSONArray()
        items.forEach { p ->
            val uris = JSONArray()
            p.mediaUris.forEach(uris::put)
            array.put(JSONObject().put("id", p.id).put("name", p.name).put("uris", uris))
        }
        prefs.edit().putString(key, array.toString()).apply()
    }
}
