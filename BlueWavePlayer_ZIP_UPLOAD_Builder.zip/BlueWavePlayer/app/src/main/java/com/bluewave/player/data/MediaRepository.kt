package com.bluewave.player.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {
    suspend fun loadVideos(folderPath: String? = null): List<MediaFile> = withContext(Dispatchers.IO) {
        query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, folderPath)
    }

    suspend fun loadAudio(folderPath: String? = null): List<MediaFile> = withContext(Dispatchers.IO) {
        query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false, folderPath)
    }

    private fun query(baseUri: android.net.Uri, video: Boolean, folderPath: String?): List<MediaFile> {
        val id = MediaStore.MediaColumns._ID
        val title = MediaStore.MediaColumns.TITLE
        val name = MediaStore.MediaColumns.DISPLAY_NAME
        val pathColumn = if (Build.VERSION.SDK_INT >= 29) MediaStore.MediaColumns.RELATIVE_PATH else MediaStore.MediaColumns.DATA
        val duration = MediaStore.MediaColumns.DURATION
        val size = MediaStore.MediaColumns.SIZE
        val modified = MediaStore.MediaColumns.DATE_MODIFIED
        val projection = arrayOf(id, title, name, pathColumn, duration, size, modified)

        val selection: String?
        val selectionArgs: Array<String>?
        if (folderPath.isNullOrBlank()) {
            selection = null
            selectionArgs = null
        } else if (Build.VERSION.SDK_INT >= 29) {
            selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            selectionArgs = arrayOf(folderPath)
        } else {
            selection = "${MediaStore.MediaColumns.DATA} LIKE ?"
            selectionArgs = arrayOf(folderPath.trimEnd('/') + "/%")
        }
        val output = ArrayList<MediaFile>()
        context.contentResolver.query(baseUri, projection, selection, selectionArgs,
            "$modified DESC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(id)
            val titleCol = cursor.getColumnIndexOrThrow(title)
            val nameCol = cursor.getColumnIndexOrThrow(name)
            val pathCol = cursor.getColumnIndex(pathColumn)
            val durationCol = cursor.getColumnIndex(duration)
            val sizeCol = cursor.getColumnIndex(size)
            val dateCol = cursor.getColumnIndex(modified)
            while (cursor.moveToNext()) {
                val mediaId = cursor.getLong(idCol)
                val displayName = cursor.getString(nameCol).orEmpty()
                val mediaTitle = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                    ?: displayName.substringBeforeLast('.', displayName)
                val rawPath = if (pathCol >= 0) cursor.getString(pathCol).orEmpty() else ""
                val relativePath = if (Build.VERSION.SDK_INT >= 29) rawPath else rawPath.substringBeforeLast('/', "")
                val durationMs = if (durationCol >= 0 && !cursor.isNull(durationCol)) cursor.getLong(durationCol) else 0L
                val sizeBytes = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                val dateModified = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                output += MediaFile(
                    id = mediaId,
                    uri = ContentUris.withAppendedId(baseUri, mediaId),
                    title = mediaTitle,
                    displayName = displayName,
                    relativePath = relativePath,
                    durationMs = durationMs,
                    sizeBytes = sizeBytes,
                    dateModified = dateModified,
                    isVideo = video
                )
            }
        }
        return output
    }

    fun folders(items: List<MediaFile>): List<MediaFolder> = items
        .groupBy { it.relativePath }
        .map { (path, files) ->
            val name = path.trimEnd('/').substringAfterLast('/').ifBlank { "Device storage" }
            MediaFolder(path, name, files.size)
        }
        .sortedBy { it.name.lowercase() }
}
