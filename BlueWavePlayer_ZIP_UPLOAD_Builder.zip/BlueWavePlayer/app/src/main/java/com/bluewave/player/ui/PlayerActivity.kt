package com.bluewave.player.ui

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.SeekParameters
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.bluewave.player.data.AppPrefs
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

@androidx.media3.common.util.UnstableApi
class PlayerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_QUEUE_URIS = "queue_uris"
        const val EXTRA_QUEUE_TITLES = "queue_titles"
        const val EXTRA_START_INDEX = "start_index"
        const val EXTRA_IS_VIDEO = "is_video"
        const val EXTRA_QUEUE_TYPES = "queue_types"
        const val EXTRA_RESUME = "resume"
    }

    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var overlayRoot: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var actionBar: HorizontalScrollView
    private lateinit var titleView: TextView
    private lateinit var feedback: TextView
    private lateinit var audioCenter: LinearLayout
    private var equalizer: Equalizer? = null
    private var audioOnly = false
    private var isVideo = true
    private var queueIsVideo: BooleanArray = booleanArrayOf(true)
    private var overlaysVisible = true
    private val handler = Handler(Looper.getMainLooper())
    private val hideOverlays = Runnable { setOverlaysVisible(false) }
    private val audioManager by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }

    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var gestureMode = 0 // 1 brightness, 2 volume
    private var startBrightness = 0.5f
    private var startVolume = 0
    private var swipeConsumed = false

    private val progressSaver = object : Runnable {
        override fun run() {
            savePlaybackState()
            if (!isFinishing) handler.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        isVideo = intent.getBooleanExtra(EXTRA_IS_VIDEO, true)
        queueIsVideo = intent.getBooleanArrayExtra(EXTRA_QUEUE_TYPES) ?: booleanArrayOf(isVideo)
        buildPlayerUi()
        initializePlayer()
        applyOrientationSetting()
        handler.postDelayed(progressSaver, 4000)
    }

    private fun buildPlayerUi() {
        overlayRoot = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = true
            controllerShowTimeoutMs = 3200
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            setBackgroundColor(Color.BLACK)
        }
        overlayRoot.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0x99000000.toInt())
        }
        topBar.addView(actionText("‹", 30f) { finish() }.apply { layoutParams = LinearLayout.LayoutParams(dp(42), dp(44)) })
        titleView = TextView(this).apply {
            text = "Now playing"
            textSize = 14f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
            gravity = Gravity.CENTER_VERTICAL
        }
        topBar.addView(titleView)
        topBar.addView(actionText("⚙", 22f) { showPlayerSettings() }.apply { layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)) })
        overlayRoot.addView(topBar, FrameLayout.LayoutParams(-1, dp(60), Gravity.TOP))

        actionBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(0x99000000.toInt())
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        actions.addView(actionText("♫  Audio", 13f) { toggleAudioOnly() })
        actions.addView(actionText("↻  Rotate", 13f) { rotateScreen() })
        actions.addView(actionText("▣  PiP", 13f) { enterPipManually() })
        actions.addView(actionText("♫  Equalizer", 13f) { showEqualizer() })
        actionBar.addView(actions)
        overlayRoot.addView(actionBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP).apply {
            topMargin = dp(60)
        })

        audioCenter = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        audioCenter.addView(TextView(this).apply {
            text = "▶"
            textSize = 54f
            setTextColor(0xFF35C8FA.toInt())
            gravity = Gravity.CENTER
        })
        audioCenter.addView(TextView(this).apply {
            text = "AUDIO MODE"
            textSize = 12f
            setTextColor(0xFFB9D9FF.toInt())
            letterSpacing = 0.16f
        })
        audioCenter.setOnClickListener { setOverlaysVisible(true); playerView.showController() }
        overlayRoot.addView(audioCenter, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        feedback = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(0xCC071B69.toInt())
            visibility = View.GONE
            gravity = Gravity.CENTER
        }
        overlayRoot.addView(feedback, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(overlayRoot)
        handler.postDelayed(hideOverlays, 3600)

        playerView.setOnTouchListener { view, event ->
            handleTouch(event, view.width.toFloat(), view.height.toFloat())
            false // Let PlayerView's built-in controller receive normal taps.
        }
    }

    private fun initializePlayer() {
        val uris = intent.getStringArrayListExtra(EXTRA_QUEUE_URIS).orEmpty()
        val titles = intent.getStringArrayListExtra(EXTRA_QUEUE_TITLES).orEmpty()
        if (uris.isEmpty()) {
            Toast.makeText(this, "No media was selected", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val startIndex = intent.getIntExtra(EXTRA_START_INDEX, 0).coerceIn(0, uris.lastIndex)
        val mediaItems = uris.mapIndexed { index, raw ->
            MediaItem.Builder()
                .setMediaId(raw)
                .setUri(Uri.parse(raw))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(titles.getOrNull(index) ?: "Media ${index + 1}").build())
                .build()
        }

        player = ExoPlayer.Builder(this)
            .setHandleAudioBecomingNoisy(true)
            .build()
        playerView.player = player
        player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        player.repeatMode = if (AppPrefs.getBoolean(this, "repeat_one", false)) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.setPauseAtEndOfMediaItems(!AppPrefs.getBoolean(this, "auto_next", true))
        player.setMediaItems(mediaItems, startIndex, C.TIME_UNSET)
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                savePlaybackState()
                isVideo = queueIsVideo.getOrElse(player.currentMediaItemIndex) { isVideo }
                audioOnly = !isVideo
                playerView.videoSurfaceView?.visibility = if (audioOnly) View.GONE else View.VISIBLE
                audioCenter.visibility = if (audioOnly) View.VISIBLE else View.GONE
                updateCurrentTitleAndLastPlayed()
                applyOrientationSetting()
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (AppPrefs.getInt(this@PlayerActivity, "orientation", 0) == 0 && videoSize.width > 0 && videoSize.height > 0) {
                    requestedOrientation = if (videoSize.width >= videoSize.height)
                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                showFeedback("Can't play this format")
                Toast.makeText(this@PlayerActivity, error.errorCodeName, Toast.LENGTH_LONG).show()
            }

        })
        player.prepare()
        val currentUri = uris[startIndex]
        val savedPosition = if (AppPrefs.getBoolean(this, "remember_position", true)) AppPrefs.getPosition(this, currentUri) else 0L
        if (savedPosition > 0L) player.seekTo(startIndex, savedPosition)
        player.playWhenReady = AppPrefs.getBoolean(this, "autoplay", true)
        updateCurrentTitleAndLastPlayed()
        if (!isVideo) toggleAudioOnly(force = true)
        if (savedPosition > 0) showFeedback("Resuming from ${formatTime(savedPosition)}")
    }

    private fun updateCurrentTitleAndLastPlayed() {
        val item = player.currentMediaItem ?: return
        val rawUri = item.mediaId.ifBlank { item.localConfiguration?.uri?.toString().orEmpty() }
        val title = item.mediaMetadata.title?.toString().orEmpty().ifBlank { Uri.parse(rawUri).lastPathSegment ?: "Now playing" }
        titleView.text = title
        AppPrefs.putString(this, "last_uri", rawUri)
        AppPrefs.putString(this, "last_title", title)
        AppPrefs.putBoolean(this, "last_is_video", isVideo)
    }

    private fun handleTouch(event: MotionEvent, viewWidth: Float, viewHeight: Float) {
        val width = viewWidth.coerceAtLeast(1f)
        val height = viewHeight.coerceAtLeast(1f)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastY = event.y
                gestureMode = 0
                swipeConsumed = false
                val margin = dp(AppPrefs.getInt(this, "gesture_margin", 64)).toFloat()
                val inside = event.x in margin..(width - margin) && event.y in margin..(height - margin)
                if (inside && abs(event.y - downY) < dp(12)) {
                    if (event.x < width / 2f && AppPrefs.getBoolean(this, "swipe_brightness", true)) {
                        gestureMode = 1
                        startBrightness = if (Build.VERSION.SDK_INT >= 23 && android.provider.Settings.System.canWrite(this)) {
                            runCatching { android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f }
                                .getOrDefault(0.5f)
                        } else window.attributes.screenBrightness.takeIf { it >= 0f } ?: 0.5f
                    } else if (event.x >= width / 2f && AppPrefs.getBoolean(this, "swipe_volume", true)) {
                        gestureMode = 2
                        startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = abs(event.x - downX)
                val dy = event.y - downY
                if (gestureMode != 0 && abs(dy) > dp(14) && abs(dy) > dx * 1.2f) {
                    swipeConsumed = true
                    val ratio = (-dy / height).coerceIn(-1f, 1f)
                    if (gestureMode == 1) {
                        val value = (startBrightness + ratio).coerceIn(0.03f, 1f)
                        if (Build.VERSION.SDK_INT >= 23 && android.provider.Settings.System.canWrite(this)) {
                            val changed = runCatching {
                                android.provider.Settings.System.putInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS, (value * 255).roundToInt())
                            }.getOrDefault(false)
                            if (!changed) {
                                val attrs = window.attributes
                                attrs.screenBrightness = value
                                window.attributes = attrs
                            }
                        } else {
                            val attrs = window.attributes
                            attrs.screenBrightness = value
                            window.attributes = attrs
                        }
                        showFeedback("Brightness  ${(value * 100).roundToInt()}%")
                    } else {
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val value = (startVolume + ratio * max).roundToInt().coerceIn(0, max)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0)
                        showFeedback("Volume  ${(value * 100f / max).roundToInt()}%")
                    }
                    lastY = event.y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (swipeConsumed) {
                    handler.removeCallbacks(hideOverlays)
                    handler.postDelayed({ feedback.visibility = View.GONE }, 750)
                }
                gestureMode = 0
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // Double-tap recognizer is attached to the video surface only, not to the whole screen.
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        // PlayerView's single tap controls playback UI. Its double-tap gesture is handled below by
        // a detector attached to the video view when available.
        attachDoubleTapListener()
    }

    private fun attachDoubleTapListener() {
        val target = playerView.videoSurfaceView ?: playerView
        val detector = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                handleDoubleTap(e.x, e.y, target.width.toFloat(), target.height.toFloat())
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                setOverlaysVisible(true)
                return false
            }
        })
        target.setOnTouchListener { view, event ->
            detector.onTouchEvent(event)
            handleTouch(event, view.width.toFloat(), view.height.toFloat())
            false
        }
    }

    private fun handleDoubleTap(x: Float, y: Float, width: Float, height: Float) {
        if (!AppPrefs.getBoolean(this, "double_tap", true)) return
        if (width <= 0 || height <= 0) return
        val left = x / width
        val top = y / height
        // Leave the extreme edges and the middle column untouched, matching the requested tap zones.
        if (top !in 0.15f..0.85f || left !in 0.12f..0.88f) return
        val delta = AppPrefs.getInt(this, "seek_seconds", 10).coerceIn(1, 120) * 1000L
        when {
            left in 0.12f..0.40f -> {
                val next = (player.currentPosition - delta).coerceAtLeast(0L)
                player.seekTo(next)
                showFeedback("−${delta / 1000}s")
            }
            left in 0.60f..0.88f -> {
                val duration = player.duration.takeIf { it != C.TIME_UNSET } ?: Long.MAX_VALUE
                val next = (player.currentPosition + delta).coerceAtMost(duration)
                player.seekTo(next)
                showFeedback("+${delta / 1000}s")
            }
            left in 0.40f..0.60f && AppPrefs.getBoolean(this, "double_tap_center", true) -> {
                if (player.isPlaying) {
                    player.pause()
                    showFeedback("Paused")
                } else {
                    player.play()
                    showFeedback("Playing")
                }
            }
            else -> return
        }
    }

    private fun toggleAudioOnly(force: Boolean = false) {
        audioOnly = if (force) true else !audioOnly
        playerView.videoSurfaceView?.visibility = if (audioOnly) View.GONE else View.VISIBLE
        audioCenter.visibility = if (audioOnly) View.VISIBLE else View.GONE
        showFeedback(if (audioOnly) "Audio only" else "Video mode")
    }

    private fun rotateScreen() {
        requestedOrientation = if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun enterPipManually() {
        if (!isVideo || audioOnly) {
            Toast.makeText(this, "Picture-in-picture is available for video playback", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 26) {
            if (!AppPrefs.getBoolean(this, "pip_enabled", true)) {
                Toast.makeText(this, "Picture-in-picture is disabled in settings", Toast.LENGTH_SHORT).show()
                return
            }
            runCatching {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            }.onFailure { Toast.makeText(this, "Picture-in-picture is unavailable", Toast.LENGTH_SHORT).show() }
        } else {
            Toast.makeText(this, "Picture-in-picture requires Android 8.0 or later", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 && isVideo && !audioOnly && player.isPlaying && AppPrefs.getBoolean(this, "pip_enabled", true)) {
            runCatching {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            actionBar.visibility = View.GONE
            audioCenter.visibility = View.GONE
        } else {
            setOverlaysVisible(true)
        }
    }

    private fun applyOrientationSetting() {
        when (AppPrefs.getInt(this, "orientation", 0)) {
            1 -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            2 -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            3 -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            4 -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else -> {
                val size = player.videoSize
                if (size.width > 0 && size.height > 0) requestedOrientation =
                    if (size.width >= size.height) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }
    }

    private fun showEqualizer() {
        try {
            if (equalizer == null) equalizer = Equalizer(0, player.audioSessionId).apply { enabled = true }
            val eq = equalizer ?: return
            val presets = (0 until eq.numberOfPresets.toInt()).map { eq.getPresetName(it.toShort()).toString() }
            if (presets.isEmpty()) {
                Toast.makeText(this, "No equalizer presets are available on this device", Toast.LENGTH_SHORT).show()
                return
            }
            AlertDialog.Builder(this).setTitle("Equalizer · presets")
                .setItems(presets.toTypedArray()) { _, which ->
                    runCatching { eq.usePreset(which.toShort()); showFeedback(presets[which]) }
                        .onFailure { Toast.makeText(this, "Preset is not supported", Toast.LENGTH_SHORT).show() }
                }.setNegativeButton("Close", null).show()
        } catch (_: Exception) {
            Toast.makeText(this, "The device audio system does not expose an equalizer", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPlayerSettings() {
        val options = arrayOf("Playback speed", "Repeat current item", "Video fit: Fit / Fill")
        AlertDialog.Builder(this).setTitle("Playback settings").setItems(options) { _, which ->
            when (which) {
                0 -> showSpeedDialog()
                1 -> {
                    val enabled = player.repeatMode != Player.REPEAT_MODE_ONE
                    player.repeatMode = if (enabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                    AppPrefs.putBoolean(this, "repeat_one", enabled)
                    Toast.makeText(this, if (enabled) "Repeat current item on" else "Repeat current item off", Toast.LENGTH_SHORT).show()
                }
                2 -> playerView.resizeMode = if (playerView.resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT)
                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        }.show()
    }

    private fun showSpeedDialog() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
        val labels = speeds.map { "${it}×" }.toTypedArray()
        val selected = speeds.indices.minByOrNull { abs(speeds[it] - player.playbackParameters.speed) } ?: 2
        AlertDialog.Builder(this).setTitle("Playback speed")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                player.setPlaybackSpeed(speeds[which])
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun actionText(label: String, size: Float, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun showFeedback(message: String) {
        feedback.text = message
        feedback.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlays)
        handler.postDelayed({ feedback.visibility = View.GONE }, 900)
        if (overlaysVisible) handler.postDelayed(hideOverlays, 3600)
    }

    private fun isInPictureInPictureModeCompat(): Boolean = Build.VERSION.SDK_INT >= 26 && isInPictureInPictureMode

    private fun setOverlaysVisible(visible: Boolean) {
        overlaysVisible = visible
        topBar.visibility = if (visible) View.VISIBLE else View.GONE
        actionBar.visibility = if (visible) View.VISIBLE else View.GONE
        if (!isInPictureInPictureModeCompat()) audioCenter.visibility = if (audioOnly) View.VISIBLE else View.GONE
        if (visible) {
            handler.removeCallbacks(hideOverlays)
            handler.postDelayed(hideOverlays, 3600)
        }
    }

    private fun savePlaybackState() {
        if (!::player.isInitialized) return
        val item = player.currentMediaItem ?: return
        val uri = item.mediaId.ifBlank { item.localConfiguration?.uri?.toString().orEmpty() }
        if (uri.isNotBlank()) AppPrefs.savePosition(this, uri, player.currentPosition)
    }

    private fun formatTime(ms: Long): String {
        val seconds = ms / 1000
        return "%d:%02d".format(seconds / 60, seconds % 60)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onPause() {
        savePlaybackState()
        super.onPause()
    }

    override fun onStop() {
        savePlaybackState()
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressSaver)
        handler.removeCallbacks(hideOverlays)
        equalizer?.release()
        if (::player.isInitialized) {
            savePlaybackState()
            playerView.player = null
            player.release()
        }
        super.onDestroy()
    }
}
