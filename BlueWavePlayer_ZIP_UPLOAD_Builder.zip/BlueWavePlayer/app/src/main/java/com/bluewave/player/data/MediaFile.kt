package com.bluewave.player.data

import android.net.Uri

/** A single item indexed from Android MediaStore. */
data class MediaFile(
    val id: Long,
    val uri: Uri,
    val title: String,
    val displayName: String,
    val relativePath: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateModified: Long,
    val isVideo: Boolean
) {
    val folderName: String
        get() = relativePath.trimEnd('/').substringAfterLast('/').ifBlank { "Device storage" }
}

data class MediaFolder(
    val relativePath: String,
    val name: String,
    val itemCount: Int
)

data class UserPlaylist(
    val id: String,
    val name: String,
    val mediaUris: List<String>
)
