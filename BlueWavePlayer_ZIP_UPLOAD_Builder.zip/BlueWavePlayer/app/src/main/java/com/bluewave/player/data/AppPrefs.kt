package com.bluewave.player.data

import android.content.Context
import java.security.MessageDigest

object AppPrefs {
    private const val PREFS = "bluewave_settings"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getInt(context: Context, key: String, default: Int) = prefs(context).getInt(key, default)
    fun putInt(context: Context, key: String, value: Int) = prefs(context).edit().putInt(key, value).apply()
    fun getBoolean(context: Context, key: String, default: Boolean) = prefs(context).getBoolean(key, default)
    fun putBoolean(context: Context, key: String, value: Boolean) = prefs(context).edit().putBoolean(key, value).apply()
    fun getString(context: Context, key: String, default: String = "") = prefs(context).getString(key, default) ?: default
    fun putString(context: Context, key: String, value: String) = prefs(context).edit().putString(key, value).apply()
    fun remove(context: Context, key: String) = prefs(context).edit().remove(key).apply()

    private fun positionKey(uri: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(uri.toByteArray(Charsets.UTF_8))
        return "position_" + digest.joinToString("") { "%02x".format(it) }
    }

    fun savePosition(context: Context, uri: String, position: Long) {
        if (getBoolean(context, "remember_position", true)) {
            prefs(context).edit().putLong(positionKey(uri), position).apply()
        }
    }

    fun getPosition(context: Context, uri: String): Long =
        prefs(context).getLong(positionKey(uri), 0L)
}
