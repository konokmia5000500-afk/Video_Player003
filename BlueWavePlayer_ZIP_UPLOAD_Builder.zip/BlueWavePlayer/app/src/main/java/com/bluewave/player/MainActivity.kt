package com.bluewave.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.bluewave.player.data.AppPrefs
import com.bluewave.player.data.MediaFile
import com.bluewave.player.data.MediaRepository
import com.bluewave.player.data.PlaylistStore
import com.bluewave.player.data.UserPlaylist
import com.bluewave.player.ui.PlayerActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private val tabVideos = 1
    private val tabAudio = 2
    private val tabPlaylists = 3
    private val tabSettings = 4

    private lateinit var repository: MediaRepository
    private lateinit var playlistStore: PlaylistStore
    private lateinit var root: LinearLayout
    private lateinit var toolbarTitle: TextView
    private lateinit var content: FrameLayout
    private lateinit var navigation: BottomNavigationView
    private lateinit var sortButton: MaterialButton

    private var activeTab = tabVideos
    private var currentFolderPath: String? = null
    private var currentPlaylist: UserPlaylist? = null
    private var latestVideos: List<MediaFile> = emptyList()
    private var latestAudio: List<MediaFile> = emptyList()
    private var loadingToken = 0
    private var lastPlayedFab: FloatingActionButton? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { renderCurrentPage() }

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedNightMode()
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        repository = MediaRepository(this)
        playlistStore = PlaylistStore(this)
        buildShell()
        renderCurrentPage()
    }

    private fun applySavedNightMode() {
        when (AppPrefs.getInt(this, "theme", 0)) {
            1 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            2, 3 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun buildShell() {
        val dark = isDarkMode()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (dark) { if (isMidnightBlue()) 0xFF07163F.toInt() else 0xFF0A1020.toInt() } else 0xFFF5F7FC.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(12), dp(12))
        }
        toolbarTitle = TextView(this).apply {
            text = "Videos"
            textSize = fontSize() + 6f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (dark) 0xFFF2F5FF.toInt() else 0xFF111B31.toInt())
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
            gravity = Gravity.CENTER_VERTICAL
        }
        sortButton = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Sort  ▾"
            textSize = 12f
            setOnClickListener { showSortDialog() }
        }
        header.addView(toolbarTitle)
        header.addView(sortButton)
        root.addView(header)

        content = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(content)

        navigation = BottomNavigationView(this).apply {
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            menu.add(0, tabVideos, 0, "Videos").setIcon(android.R.drawable.ic_media_play)
            menu.add(0, tabAudio, 1, "Audio").setIcon(android.R.drawable.ic_lock_silent_mode_off)
            menu.add(0, tabPlaylists, 2, "Playlists").setIcon(android.R.drawable.ic_menu_agenda)
            menu.add(0, tabSettings, 3, "Settings").setIcon(android.R.drawable.ic_menu_manage)
            setOnItemSelectedListener { item ->
                if (item.itemId != activeTab) {
                    activeTab = item.itemId
                    currentFolderPath = null
                    currentPlaylist = null
                    renderCurrentPage()
                }
                true
            }
        }
        root.addView(navigation)
        setContentView(root)
        navigation.selectedItemId = tabVideos
    }

    private fun renderCurrentPage() {
        loadingToken++
        val token = loadingToken
        toolbarTitle.text = when (activeTab) {
            tabVideos -> currentFolderPath?.trimEnd('/')?.substringAfterLast('/') ?: "Videos"
            tabAudio -> currentFolderPath?.trimEnd('/')?.substringAfterLast('/') ?: "Audio"
            tabPlaylists -> currentPlaylist?.name ?: "Playlists"
            else -> "Settings"
        }
        sortButton.visibility = if (activeTab == tabSettings || activeTab == tabPlaylists) View.GONE else View.VISIBLE
        content.removeAllViews()

        when (activeTab) {
            tabVideos, tabAudio -> {
                if (!hasMediaPermission(activeTab == tabVideos)) {
                    showPermissionView()
                } else {
                    showLoading()
                    lifecycleScope.launch {
                        val isVideo = activeTab == tabVideos
                        val items = if (isVideo) repository.loadVideos(currentFolderPath) else repository.loadAudio(currentFolderPath)
                        if (token != loadingToken || isFinishing) return@launch
                        val ordered = sortMedia(items)
                        if (isVideo) latestVideos = ordered else latestAudio = ordered
                        if (currentFolderPath == null) showFolderList(repository.folders(items), isVideo)
                        else showMediaList(ordered, isVideo)
                    }
                }
            }
            tabPlaylists -> renderPlaylists()
            tabSettings -> renderSettings()
        }
        updateLastPlayedButton()
    }

    private fun hasMediaPermission(video: Boolean): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            val required = if (video) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_MEDIA_AUDIO
            ContextCompat.checkSelfPermission(this, required) == PackageManager.PERMISSION_GRANTED ||
                (video && Build.VERSION.SDK_INT >= 34 && ContextCompat.checkSelfPermission(
                    this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                ) == PackageManager.PERMISSION_GRANTED)
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestMediaPermissions() {
        val permissions = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= 33 -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(permissions)
    }

    private fun showPermissionView() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(24), dp(28), dp(24))
        }
        panel.addView(textView("Allow media access", 20f, true).apply { gravity = Gravity.CENTER })
        panel.addView(textView("BlueWave Player uses Android MediaStore to find video and audio files and group them by folder.", 14f, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(18))
        })
        panel.addView(MaterialButton(this).apply {
            text = "Grant access"
            setOnClickListener { requestMediaPermissions() }
        })
        content.addView(panel, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showLoading() {
        content.addView(textView("Scanning media…", 14f, false).apply {
            gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showFolderList(folders: List<com.bluewave.player.data.MediaFolder>, isVideo: Boolean) {
        val wrapper = pageWrapper()
        if (folders.isEmpty()) {
            wrapper.addView(emptyState(if (isVideo) "No videos found" else "No audio files found", "Media files will appear here after they are added to shared device storage."))
        } else {
            folders.forEach { folder ->
                wrapper.addView(folderCard(folder.name, "${folder.itemCount} ${if (isVideo) "videos" else "audio files"}", folder.relativePath) {
                    currentFolderPath = folder.relativePath
                    renderCurrentPage()
                })
            }
        }
        content.addView(wrapPage(wrapper), FrameLayout.LayoutParams(-1, -1))
    }

    private fun showMediaList(items: List<MediaFile>, isVideo: Boolean) {
        val wrapper = pageWrapper()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        top.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonTextButtonStyle).apply {
            text = "‹ Folders"
            setOnClickListener { currentFolderPath = null; renderCurrentPage() }
        })
        top.addView(textView("${items.size} items", 12f, false).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
            textAlignment = View.TEXT_ALIGNMENT_TEXT_END
        })
        wrapper.addView(top)
        if (items.isEmpty()) wrapper.addView(emptyState("This folder is empty", "No supported ${if (isVideo) "video" else "audio"} files were indexed in this folder."))
        items.forEach { item ->
            wrapper.addView(mediaCard(item))
        }
        content.addView(wrapPage(wrapper), FrameLayout.LayoutParams(-1, -1))
    }

    private fun renderPlaylists() {
        val wrapper = pageWrapper()
        if (currentPlaylist == null) {
            val playlists = playlistStore.all()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(12))
            }
            row.addView(textView("Your collections", 14f, true).apply {
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                gravity = Gravity.CENTER_VERTICAL
            })
            row.addView(MaterialButton(this).apply {
                text = "+ New playlist"
                setOnClickListener { showCreatePlaylistDialog() }
            })
            wrapper.addView(row)
            if (playlists.isEmpty()) wrapper.addView(emptyState("No playlists yet", "Create a playlist, then add tracks or videos from their item menu."))
            playlists.forEach { p ->
                wrapper.addView(folderCard(p.name, "${p.mediaUris.size} items", "playlist:${p.id}") {
                    currentPlaylist = p
                    renderCurrentPage()
                }.apply {
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle(p.name)
                            .setItems(arrayOf("Delete playlist")) { _, _ ->
                                playlistStore.delete(p.id)
                                renderCurrentPage()
                            }.show()
                        true
                    }
                })
            }
        } else {
            wrapper.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonTextButtonStyle).apply {
                text = "‹ All playlists"
                setOnClickListener { currentPlaylist = null; renderCurrentPage() }
            })
            lifecycleScope.launch {
                val videos = if (hasMediaPermission(true)) repository.loadVideos() else emptyList()
                val audios = if (hasMediaPermission(false)) repository.loadAudio() else emptyList()
                latestVideos = videos
                latestAudio = audios
                val byUri = (videos + audios).associateBy { it.uri.toString() }
                val queue = currentPlaylist?.mediaUris?.mapNotNull { byUri[it] }.orEmpty()
                currentPlaylist?.mediaUris?.forEach { raw ->
                    val file = byUri[raw]
                    if (file != null) wrapper.addView(mediaCard(file, queue))
                    else wrapper.addView(emptyState("Unavailable media", Uri.parse(raw).lastPathSegment ?: raw))
                }
            }
        }
        content.addView(wrapPage(wrapper), FrameLayout.LayoutParams(-1, -1))
    }

    private fun renderSettings() {
        val wrapper = pageWrapper()
        wrapper.addView(sectionTitle("Appearance"))
        val fontRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val fontLabel = textView("Font size · ${fontSize()} sp", 14f, true)
        fontRow.addView(fontLabel)
        val seek = SeekBar(this).apply {
            max = 12
            progress = fontSize() - 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    val actual = value.coerceIn(0, 12) + 12
                    fontLabel.text = "Font size · $actual sp"
                    if (fromUser) AppPrefs.putInt(this@MainActivity, "font_size", actual)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                override fun onStopTrackingTouch(bar: SeekBar?) { renderCurrentPage() }
            })
        }
        fontRow.addView(seek)
        wrapper.addView(settingContainer(fontRow))
        wrapper.addView(settingRow("App theme", themeName(), "Choose system, light, dark or midnight blue") {
            showChoiceDialog("App theme", listOf("System default", "Light", "Dark", "Midnight blue"), "theme", 0) {
                applySavedNightMode(); recreate()
            }
        })

        wrapper.addView(sectionTitle("Playback"))
        wrapper.addView(settingRow("Double-tap seek", "${AppPrefs.getInt(this, "seek_seconds", 10)} seconds", "Set the jump distance for both sides of the video") {
            showNumberDialog("Double-tap seek (seconds)", "seek_seconds", 10, 1, 120)
        })
        wrapper.addView(switchRow("Enable double-tap seeking", "Skip backward or forward by tapping the left or right zone", "double_tap", true))
        wrapper.addView(switchRow("Center double-tap play / pause", "Toggle playback from the middle zone", "double_tap_center", true))
        wrapper.addView(switchRow("Play next item automatically", "Continue to the next item in the current queue", "auto_next", true))
        wrapper.addView(switchRow("Resume from last position", "Remember where each file was last played", "remember_position", true))
        wrapper.addView(switchRow("Repeat current item", "Loop the currently playing item", "repeat_one", false))
        wrapper.addView(switchRow("Start playback automatically", "Play immediately when a media item is opened", "autoplay", true))

        wrapper.addView(sectionTitle("Gestures"))
        wrapper.addView(switchRow("Swipe to change brightness", "Use the left half of the video area", "swipe_brightness", true))
        wrapper.addView(switchRow("Swipe to change volume", "Use the right half of the video area", "swipe_volume", true))
        wrapper.addView(settingRow("System brightness access", if (Build.VERSION.SDK_INT >= 23 && android.provider.Settings.System.canWrite(this)) "Enabled" else "Optional permission", "Allow the gesture to change Android system brightness globally") {
            if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.System.canWrite(this)) {
                val intent = Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                runCatching { startActivity(intent) }.onFailure {
                    Toast.makeText(this, "Open Android Settings to allow modify-system-settings access", Toast.LENGTH_LONG).show()
                }
            } else Toast.makeText(this, "System brightness access is ready", Toast.LENGTH_SHORT).show()
        })
        wrapper.addView(settingRow("Gesture edge margin", "${AppPrefs.getInt(this, "gesture_margin", 64)} dp", "Keep gestures away from the screen edges") {
            showNumberDialog("Gesture edge margin (dp)", "gesture_margin", 64, 24, 160)
        })

        wrapper.addView(sectionTitle("Screen"))
        wrapper.addView(settingRow("Video orientation", orientationName(), "Choose how the player rotates") {
            showChoiceDialog("Video orientation", listOf("Follow video size", "System default", "Sensor", "Landscape", "Portrait"), "orientation", 0)
        })
        wrapper.addView(switchRow("Picture-in-picture", "Allow the player to become a floating system window", "pip_enabled", true))
        wrapper.addView(settingRow("Library sort order", sortName(), "Choose the default order for video and audio lists") {
            showChoiceDialog("Library sort order", listOf("Date added · newest first", "Name · A to Z", "File size · largest first", "Duration · longest first"), "sort_by", 0)
        })

        wrapper.addView(sectionTitle("About"))
        wrapper.addView(settingRow("BlueWave Player", "Version 1.0.0 · Media3 engine", "Local media player project") {})
        content.addView(wrapPage(wrapper), FrameLayout.LayoutParams(-1, -1))
    }

    private fun switchRow(title: String, subtitle: String, key: String, default: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        labels.addView(textView(title, 14f, true))
        labels.addView(textView(subtitle, 11f, false).apply { setPadding(0, dp(3), 0, 0) })
        val toggle = com.google.android.material.switchmaterial.SwitchMaterial(this).apply {
            isChecked = AppPrefs.getBoolean(this@MainActivity, key, default)
            setOnCheckedChangeListener { _, checked -> AppPrefs.putBoolean(this@MainActivity, key, checked) }
        }
        row.addView(labels)
        row.addView(toggle)
        return settingContainer(row)
    }

    private fun settingRow(title: String, value: String, subtitle: String, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        labels.addView(textView(title, 14f, true))
        labels.addView(textView(subtitle, 11f, false).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(labels)
        row.addView(textView(value, 12f, true).apply { setTextColor(0xFF4B8AF5.toInt()) })
        return settingContainer(row)
    }

    private fun settingContainer(child: View): View = MaterialCardView(this).apply {
        radius = dp(14).toFloat()
        cardElevation = 0f
        strokeWidth = dp(1)
        setStrokeColor(if (isDarkMode()) { if (isMidnightBlue()) 0xFF29447E.toInt() else 0xFF26324A.toInt() } else 0xFFE4EAF4.toInt())
        setCardBackgroundColor(if (isDarkMode()) { if (isMidnightBlue()) 0xFF0D285C.toInt() else 0xFF121D31.toInt() } else 0xFFFFFFFF.toInt())
        addView(child)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
    }

    private fun sectionTitle(value: String) = textView(value, 12f, true).apply {
        setTextColor(0xFF4B8AF5.toInt())
        setPadding(dp(4), dp(18), dp(4), dp(8))
    }

    private fun showCreatePlaylistDialog() {
        val input = EditText(this).apply { hint = "Playlist name"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Create playlist").setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    currentPlaylist = null
                    playlistStore.create(name)
                    renderCurrentPage()
                }
            }.show()
    }

    private fun addToPlaylist(file: MediaFile) {
        val playlists = playlistStore.all()
        if (playlists.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Create a playlist first.")
                .setPositiveButton("Create playlist") { _, _ -> showCreatePlaylistDialog() }
                .setNegativeButton("Cancel", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Add to playlist")
            .setItems(playlists.map { it.name }.toTypedArray()) { _, which ->
                playlistStore.add(playlists[which].id, file.uri.toString())
                Toast.makeText(this, "Added to ${playlists[which].name}", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showNumberDialog(title: String, key: String, default: Int, min: Int, max: Int) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(AppPrefs.getInt(this@MainActivity, key, default).toString())
            selectAll()
        }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().toIntOrNull()
                if (value == null || value !in min..max) {
                    Toast.makeText(this, "Enter a value from $min to $max", Toast.LENGTH_SHORT).show()
                } else {
                    AppPrefs.putInt(this, key, value)
                    renderCurrentPage()
                }
            }.show()
    }

    private fun showChoiceDialog(title: String, options: List<String>, key: String, default: Int, after: () -> Unit = {}) {
        val selected = AppPrefs.getInt(this, key, default).coerceIn(options.indices)
        AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options.toTypedArray(), selected) { dialog, which ->
            AppPrefs.putInt(this, key, which)
            dialog.dismiss()
            after()
            if (key != "theme") renderCurrentPage()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun showSortDialog() {
        showChoiceDialog("Sort by", listOf("Date · newest first", "Name · A to Z", "File size · largest first", "Duration · longest first"), "sort_by", 0)
    }

    private fun sortMedia(items: List<MediaFile>): List<MediaFile> = when (AppPrefs.getInt(this, "sort_by", 0)) {
        1 -> items.sortedBy { it.title.lowercase() }
        2 -> items.sortedByDescending { it.sizeBytes }
        3 -> items.sortedByDescending { it.durationMs }
        else -> items.sortedByDescending { it.dateModified }
    }

    private fun mediaCard(file: MediaFile, queueOverride: List<MediaFile>? = null): View {
        val card = MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = 0f
            strokeWidth = dp(1)
            setStrokeColor(if (isDarkMode()) { if (isMidnightBlue()) 0xFF29447E.toInt() else 0xFF26324A.toInt() } else 0xFFE4EAF4.toInt())
            setCardBackgroundColor(if (isDarkMode()) { if (isMidnightBlue()) 0xFF0D285C.toInt() else 0xFF121D31.toInt() } else 0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(8), dp(12))
        }
        val glyph = textView(if (file.isVideo) "▶" else "♫", 21f, true).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFF198EF2.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) } }
        labels.addView(textView(file.title, 14f, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        val meta = listOf(formatDuration(file.durationMs), formatBytes(file.sizeBytes), DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(file.dateModified * 1000))).filter { it.isNotBlank() }.joinToString("  ·  ")
        labels.addView(textView(meta, 11f, false).apply { setPadding(0, dp(4), 0, 0); maxLines = 1 })
        val more = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonTextButtonStyle).apply {
            text = "⋮"
            minWidth = dp(38)
            setOnClickListener { showMediaMenu(file, queueOverride) }
        }
        row.addView(glyph); row.addView(labels); row.addView(more)
        card.addView(row)
        card.setOnClickListener { openPlayer(file, queueOverride ?: if (file.isVideo) latestVideos else latestAudio) }
        card.setOnLongClickListener { showMediaMenu(file, queueOverride); true }
        return card
    }

    private fun showMediaMenu(file: MediaFile, queueOverride: List<MediaFile>? = null) {
        AlertDialog.Builder(this).setTitle(file.title)
            .setItems(arrayOf("Play", "Add to playlist", "Share")) { _, which ->
                when (which) {
                    0 -> openPlayer(file, queueOverride ?: if (file.isVideo) latestVideos else latestAudio)
                    1 -> addToPlaylist(file)
                    2 -> {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = if (file.isVideo) "video/*" else "audio/*"
                            putExtra(Intent.EXTRA_STREAM, file.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(send, "Share media"))
                    }
                }
            }.show()
    }

    private fun openPlayer(file: MediaFile, sourceQueue: List<MediaFile>) {
        val queue = sourceQueue.ifEmpty { listOf(file) }
        val start = queue.indexOfFirst { it.uri == file.uri }.coerceAtLeast(0)
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra(PlayerActivity.EXTRA_QUEUE_URIS, ArrayList(queue.map { it.uri.toString() }))
            putStringArrayListExtra(PlayerActivity.EXTRA_QUEUE_TITLES, ArrayList(queue.map { it.title }))
            putExtra(PlayerActivity.EXTRA_START_INDEX, start)
            putExtra(PlayerActivity.EXTRA_IS_VIDEO, file.isVideo)
            putExtra(PlayerActivity.EXTRA_QUEUE_TYPES, queue.map { it.isVideo }.toBooleanArray())
        }
        startActivity(intent)
    }

    private fun folderCard(title: String, subtitle: String, tag: String, onClick: () -> Unit): MaterialCardView {
        return MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = 0f
            strokeWidth = dp(1)
            setStrokeColor(if (isDarkMode()) { if (isMidnightBlue()) 0xFF29447E.toInt() else 0xFF26324A.toInt() } else 0xFFE4EAF4.toInt())
            setCardBackgroundColor(if (isDarkMode()) { if (isMidnightBlue()) 0xFF0D285C.toInt() else 0xFF121D31.toInt() } else 0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
            row.addView(textView(if (tag.startsWith("playlist:")) "▤" else "▰", 23f, true).apply {
                setTextColor(0xFF248EF2.toInt()); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            })
            val labels = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) } }
            labels.addView(textView(title, 15f, true))
            labels.addView(textView(subtitle, 11f, false).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(labels)
            row.addView(textView("›", 24f, false).apply { setTextColor(0xFF8EA0BC.toInt()) })
            addView(row)
            setOnClickListener { onClick() }
        }
    }

    private fun emptyState(title: String, detail: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(24), dp(45), dp(24), dp(45))
        addView(textView(title, 17f, true).apply { gravity = Gravity.CENTER })
        addView(textView(detail, 12f, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
    }

    private fun pageWrapper() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(6), dp(16), dp(12))
    }

    private fun wrapPage(column: LinearLayout) = ScrollView(this).apply {
        isFillViewport = true
        clipToPadding = false
        addView(column, ScrollView.LayoutParams(-1, -2))
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) updateLastPlayedButton()
    }

    private fun updateLastPlayedButton() {
        lastPlayedFab?.let { content.removeView(it) }
        lastPlayedFab = null
        val lastUri = AppPrefs.getString(this, "last_uri")
        if (activeTab == tabSettings || lastUri.isBlank()) return
        val fab = FloatingActionButton(this).apply {
            contentDescription = "Resume last played item"
            setImageResource(com.bluewave.player.R.drawable.ic_play_mark)
            size = FloatingActionButton.SIZE_NORMAL
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF0B2A9A.toInt())
            setOnClickListener {
                val title = AppPrefs.getString(this@MainActivity, "last_title", "Recently played")
                val isVideo = AppPrefs.getBoolean(this@MainActivity, "last_is_video", true)
                val intent = Intent(this@MainActivity, PlayerActivity::class.java).apply {
                    putStringArrayListExtra(PlayerActivity.EXTRA_QUEUE_URIS, arrayListOf(lastUri))
                    putStringArrayListExtra(PlayerActivity.EXTRA_QUEUE_TITLES, arrayListOf(title))
                    putExtra(PlayerActivity.EXTRA_START_INDEX, 0)
                    putExtra(PlayerActivity.EXTRA_IS_VIDEO, isVideo)
                    putExtra(PlayerActivity.EXTRA_QUEUE_TYPES, booleanArrayOf(isVideo))
                    putExtra(PlayerActivity.EXTRA_RESUME, true)
                }
                startActivity(intent)
            }
        }
        lastPlayedFab = fab
        content.addView(fab, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(20), dp(18))
        })
    }

    private fun textView(text: String, size: Float, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = (size + (fontSize() - 16) * 0.35f).coerceAtLeast(10f)
        setTextColor(if (isDarkMode()) 0xFFE9EEFA.toInt() else 0xFF182238.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun fontSize() = AppPrefs.getInt(this, "font_size", 16).coerceIn(12, 24)
    private fun isDarkMode() = AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES ||
        (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM && (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES)
    private fun isMidnightBlue() = AppPrefs.getInt(this, "theme", 0) == 3
    private fun themeName() = listOf("System default", "Light", "Dark", "Midnight blue")[AppPrefs.getInt(this, "theme", 0).coerceIn(0, 3)]
    private fun orientationName() = listOf("Follow video size", "System default", "Sensor", "Landscape", "Portrait")[AppPrefs.getInt(this, "orientation", 0).coerceIn(0, 4)]
    private fun sortName() = listOf("Date · newest first", "Name · A to Z", "File size · largest first", "Duration · longest first")[AppPrefs.getInt(this, "sort_by", 0).coerceIn(0, 3)]
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatDuration(ms: Long): String {
        if (ms <= 0) return ""
        val total = ms / 1000
        return "%d:%02d".format(total / 60, total % 60)
    }
    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024L * 1024L -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
        bytes >= 1024L * 1024L -> "%.0f MB".format(bytes / (1024.0 * 1024))
        bytes >= 1024L -> "%.0f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }

    override fun onBackPressed() {
        when {
            currentFolderPath != null -> { currentFolderPath = null; renderCurrentPage() }
            currentPlaylist != null -> { currentPlaylist = null; renderCurrentPage() }
            activeTab != tabVideos -> { activeTab = tabVideos; navigation.selectedItemId = tabVideos; renderCurrentPage() }
            else -> super.onBackPressed()
        }
    }
}
