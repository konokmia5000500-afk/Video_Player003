# BlueWave Player — Android project

A native Kotlin Android media-player starter project with a clean blue interface inspired by familiar local media players. The supplied reference image's play-mark has been redrawn as a small vector asset and is used for the launcher and the floating “resume last item” button.

## Open and build

1. Extract the downloaded `BlueWavePlayer_AndroidStudio_Project.zip`.
2. Open the extracted **BlueWavePlayer** folder in Android Studio (`File → Open`).
3. Use JDK 17, allow Gradle sync, and install Android SDK Platform 36 if Android Studio asks for it.
4. Connect an Android device or start an emulator, then press **Run**.
5. To create an APK: `Build → Build Bundle(s) / APK(s) → Build APK(s)`. The debug APK is normally written under `app/build/outputs/apk/debug/`.

The included `gradlew` / `gradlew.bat` scripts bootstrap Gradle 8.13 the first time they run. An internet connection is needed for the initial Gradle and Maven dependency downloads. Android Studio can also use its configured Gradle distribution.

## Included features

- Four bottom tabs: **Videos**, **Audio**, **Playlists**, **Settings**.
- MediaStore library scan, grouped by `RELATIVE_PATH` folders on Android 10+.
- Video/audio file lists, sort by date, name, size, or duration.
- User playlists: create, add media, open, and delete.
- Media3 / ExoPlayer playback using the device's hardware decoders where supported.
- Double-tap zones: left 12–40% seeks backward, right 60–88% seeks forward, and the center 40–60% toggles play/pause. The top/bottom bands and outer edges are excluded. The skip interval is configurable from 1 to 120 seconds.
- Vertical swipe controls: left half adjusts this player window's screen brightness; right half adjusts the Android media-volume stream. The gesture margin is configurable.
- Quick actions: audio-only mode, orientation toggle, Picture-in-Picture, and device equalizer presets.
- Resume last item from a floating logo button on library and playlist pages.
- Optional resume position, auto-next, repeat-one, and autoplay settings.
- App theme selection, adjustable UI font size, and orientation preferences.

## Project structure

```text
BlueWavePlayer/
├── app/
│   ├── src/main/AndroidManifest.xml
│   ├── src/main/java/com/bluewave/player/
│   │   ├── MainActivity.kt
│   │   ├── data/
│   │   │   ├── AppPrefs.kt
│   │   │   ├── MediaFile.kt
│   │   │   ├── MediaRepository.kt
│   │   │   └── PlaylistStore.kt
│   │   └── ui/PlayerActivity.kt
│   └── build.gradle.kts
├── gradle/wrapper/gradle-wrapper.properties
├── build.gradle.kts
└── settings.gradle.kts
```

## Performance and playback notes

- ExoPlayer prepares media asynchronously and uses Android's platform codec pipeline. The app does not decode video frames itself and does not load the full media file into RAM.
- Seeking uses `SeekParameters.CLOSEST_SYNC` to favor fast jumps to nearby keyframes. The display can move to a nearby keyframe rather than the exact requested millisecond. Actual seek delay still depends on codec, keyframe spacing, file/storage speed, and device decoder behavior; zero-delay seeking cannot be guaranteed for every file.
- The PlayerView buffering spinner is disabled to avoid a distracting spinner on short local seeks. It does **not** remove actual decoder or storage buffering.
- Compatibility is limited to formats/codecs supported by Android's media framework and the device. This project does not bundle FFmpeg software decoders.
- The equalizer uses Android `android.media.audiofx.Equalizer`; available presets depend on device firmware/audio effects.
- The brightness gesture can adjust Android global screen brightness after the user grants optional “Modify system settings” access in Android Settings; otherwise it falls back to brightness for the player window only. Volume swipe adjusts the system music stream.
- Picture-in-Picture requires Android 8.0 (API 26) or later and system/user support.
- This initial project keeps the ExoPlayer instance inside `PlayerActivity`. PiP and playback while that activity is alive are supported, but a production-grade persistent background audio experience should move playback into a `MediaSessionService` with a media notification and foreground-service lifecycle.
- Media access is limited to media items Android exposes through MediaStore and the granted media permissions. On Android 13+ video and audio permissions are separate; Android 14+ may grant selected-video access only. App-private folders and arbitrary files outside the shared media index are not enumerated.

## Build configuration

- Kotlin: 2.4.21
- Android Gradle Plugin: 8.13.2
- Gradle: 8.13
- Compile / target SDK: 36
- Minimum SDK: 23
- AndroidX Media3: 1.11.1 (stable release)
- AndroidX Lifecycle: 2.11.1

## Before publishing

Test on the target phone with representative MP4/H.264, HEVC, WebM, MKV, MP3, AAC, and other expected files. Verify Android 13–16 permission flows, orientation behavior, PiP, equalizer effects, audio focus, and seek latency on real devices. Add a `MediaSessionService` before advertising persistent background audio. Configure a release signing key and review Play policy/privacy disclosures before distribution.


## Build APK by uploading only this project ZIP

The workflow is supplied separately as `build-apk.yml`. To build from one uploaded ZIP:

1. Create a GitHub repository.
2. Upload this Android project ZIP to the repository root **without extracting it**.
3. Upload the separate workflow file to `.github/workflows/build-apk.yml`.
4. Commit both files to `main` or `master`. A push of the ZIP starts the workflow automatically.
5. Or open **Actions → Build APK from uploaded ZIP → Run workflow**.
6. After a successful run, download the `BlueWavePlayer-arm64-v8a-APK-ZIP` artifact. It contains one ARM64 APK.

Keep exactly one Android project `.zip` in the repository root. The workflow extracts it, locates `settings.gradle.kts` and `gradlew`, builds the release APK, and uploads a ZIP containing the APK.

**Signing note:** each run creates a temporary signing key. The APK can be installed as a fresh install, but a later build cannot update it in place. A permanent keystore in GitHub Secrets is needed for in-place updates. The output targets `arm64-v8a` only.

The APK is already compressed internally, so wrapping it in ZIP may reduce download size only slightly.
